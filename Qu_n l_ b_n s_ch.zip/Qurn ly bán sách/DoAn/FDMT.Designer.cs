﻿namespace DoAn
{
    partial class FDMT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FDMT));
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ptb = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtnxb = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtgiasach = new System.Windows.Forms.TextBox();
            this.txtmasach = new System.Windows.Forms.TextBox();
            this.txttensach = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lvdms = new System.Windows.Forms.ListView();
            this.ID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.masach = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tensach = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.giaban = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.nxb = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.HinhAnh = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnsearch = new System.Windows.Forms.Button();
            this.txtsearch = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.btnChon = new System.Windows.Forms.Button();
            this.btnHuy = new System.Windows.Forms.Button();
            this.btnMua = new System.Windows.Forms.Button();
            this.bntthue = new System.Windows.Forms.Button();
            this.lvChon = new System.Windows.Forms.ListView();
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtTongTien = new System.Windows.Forms.TextBox();
            this.txtGiaThue = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnNhapTenKhachHang = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptb)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(188)))), ((int)(((byte)(156)))));
            this.label1.Location = new System.Drawing.Point(276, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(182, 41);
            this.label1.TabIndex = 1;
            this.label1.Text = "Mua Thuê";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ptb);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtnxb);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtgiasach);
            this.groupBox1.Controls.Add(this.txtmasach);
            this.groupBox1.Controls.Add(this.txttensach);
            this.groupBox1.Location = new System.Drawing.Point(21, 73);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(453, 195);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Chi tiết";
            // 
            // ptb
            // 
            this.ptb.Location = new System.Drawing.Point(317, 36);
            this.ptb.Name = "ptb";
            this.ptb.Size = new System.Drawing.Size(120, 120);
            this.ptb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ptb.TabIndex = 2;
            this.ptb.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 167);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "NXB";
            // 
            // txtnxb
            // 
            this.txtnxb.Location = new System.Drawing.Point(61, 164);
            this.txtnxb.Name = "txtnxb";
            this.txtnxb.Size = new System.Drawing.Size(205, 20);
            this.txtnxb.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 113);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Giá bán";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 24);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 13);
            this.label6.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "Mã sách";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tên sách";
            // 
            // txtgiasach
            // 
            this.txtgiasach.Location = new System.Drawing.Point(61, 110);
            this.txtgiasach.Name = "txtgiasach";
            this.txtgiasach.Size = new System.Drawing.Size(205, 20);
            this.txtgiasach.TabIndex = 0;
            // 
            // txtmasach
            // 
            this.txtmasach.Location = new System.Drawing.Point(61, 24);
            this.txtmasach.Name = "txtmasach";
            this.txtmasach.Size = new System.Drawing.Size(205, 20);
            this.txtmasach.TabIndex = 0;
            // 
            // txttensach
            // 
            this.txttensach.Location = new System.Drawing.Point(61, 64);
            this.txttensach.Name = "txttensach";
            this.txttensach.Size = new System.Drawing.Size(205, 20);
            this.txttensach.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lvdms);
            this.groupBox2.Location = new System.Drawing.Point(21, 348);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(437, 124);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Danh sách";
            // 
            // lvdms
            // 
            this.lvdms.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ID,
            this.masach,
            this.tensach,
            this.giaban,
            this.nxb,
            this.HinhAnh});
            this.lvdms.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lvdms.FullRowSelect = true;
            this.lvdms.Location = new System.Drawing.Point(6, 19);
            this.lvdms.MultiSelect = false;
            this.lvdms.Name = "lvdms";
            this.lvdms.Size = new System.Drawing.Size(425, 97);
            this.lvdms.TabIndex = 0;
            this.lvdms.UseCompatibleStateImageBehavior = false;
            this.lvdms.View = System.Windows.Forms.View.Details;
            this.lvdms.SelectedIndexChanged += new System.EventHandler(this.lvdms_SelectedIndexChanged2);
            // 
            // ID
            // 
            this.ID.Text = "ID";
            this.ID.Width = 0;
            // 
            // masach
            // 
            this.masach.Text = "Mã sách";
            // 
            // tensach
            // 
            this.tensach.Text = "Tên sách";
            this.tensach.Width = 168;
            // 
            // giaban
            // 
            this.giaban.Text = "Giá bán";
            this.giaban.Width = 113;
            // 
            // nxb
            // 
            this.nxb.Text = "Mã NXB";
            this.nxb.Width = 66;
            // 
            // HinhAnh
            // 
            this.HinhAnh.Text = "Anh";
            this.HinhAnh.Width = 0;
            // 
            // btnsearch
            // 
            this.btnsearch.BackColor = System.Drawing.Color.White;
            this.btnsearch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnsearch.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(188)))), ((int)(((byte)(156)))));
            this.btnsearch.FlatAppearance.BorderSize = 3;
            this.btnsearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsearch.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(188)))), ((int)(((byte)(156)))));
            this.btnsearch.Image = ((System.Drawing.Image)(resources.GetObject("btnsearch.Image")));
            this.btnsearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnsearch.Location = new System.Drawing.Point(53, 293);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(80, 39);
            this.btnsearch.TabIndex = 3;
            this.btnsearch.Text = "   Tìm";
            this.btnsearch.UseVisualStyleBackColor = false;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // txtsearch
            // 
            // 
            // 
            // 
            this.txtsearch.Border.Class = "TextBoxBorder";
            this.txtsearch.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtsearch.Location = new System.Drawing.Point(162, 308);
            this.txtsearch.Name = "txtsearch";
            this.txtsearch.PreventEnterBeep = true;
            this.txtsearch.Size = new System.Drawing.Size(209, 20);
            this.txtsearch.TabIndex = 4;
            this.txtsearch.WatermarkText = "Tên sách, mã sách, mã nhà xuất bản";
            // 
            // btnChon
            // 
            this.btnChon.BackColor = System.Drawing.Color.White;
            this.btnChon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnChon.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(188)))), ((int)(((byte)(156)))));
            this.btnChon.FlatAppearance.BorderSize = 3;
            this.btnChon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChon.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChon.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(188)))), ((int)(((byte)(156)))));
            this.btnChon.Location = new System.Drawing.Point(23, 218);
            this.btnChon.Name = "btnChon";
            this.btnChon.Size = new System.Drawing.Size(75, 51);
            this.btnChon.TabIndex = 6;
            this.btnChon.Text = "Chọn";
            this.btnChon.UseVisualStyleBackColor = false;
            this.btnChon.Click += new System.EventHandler(this.btnChon_Click);
            // 
            // btnHuy
            // 
            this.btnHuy.BackColor = System.Drawing.Color.White;
            this.btnHuy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHuy.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(188)))), ((int)(((byte)(156)))));
            this.btnHuy.FlatAppearance.BorderSize = 3;
            this.btnHuy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHuy.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHuy.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(188)))), ((int)(((byte)(156)))));
            this.btnHuy.Location = new System.Drawing.Point(127, 218);
            this.btnHuy.Name = "btnHuy";
            this.btnHuy.Size = new System.Drawing.Size(75, 51);
            this.btnHuy.TabIndex = 6;
            this.btnHuy.Text = "Hủy";
            this.btnHuy.UseVisualStyleBackColor = false;
            this.btnHuy.Click += new System.EventHandler(this.btnHuy_Click);
            // 
            // btnMua
            // 
            this.btnMua.BackColor = System.Drawing.Color.White;
            this.btnMua.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMua.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(188)))), ((int)(((byte)(156)))));
            this.btnMua.FlatAppearance.BorderSize = 3;
            this.btnMua.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMua.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMua.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(188)))), ((int)(((byte)(156)))));
            this.btnMua.Location = new System.Drawing.Point(464, 416);
            this.btnMua.Name = "btnMua";
            this.btnMua.Size = new System.Drawing.Size(75, 48);
            this.btnMua.TabIndex = 7;
            this.btnMua.Text = "Mua";
            this.btnMua.UseVisualStyleBackColor = false;
            this.btnMua.Click += new System.EventHandler(this.btnMua_Click);
            // 
            // bntthue
            // 
            this.bntthue.BackColor = System.Drawing.Color.White;
            this.bntthue.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bntthue.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(188)))), ((int)(((byte)(156)))));
            this.bntthue.FlatAppearance.BorderSize = 3;
            this.bntthue.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bntthue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntthue.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(188)))), ((int)(((byte)(156)))));
            this.bntthue.Location = new System.Drawing.Point(626, 416);
            this.bntthue.Name = "bntthue";
            this.bntthue.Size = new System.Drawing.Size(75, 48);
            this.bntthue.TabIndex = 7;
            this.bntthue.Text = "Thuê";
            this.bntthue.UseVisualStyleBackColor = false;
            this.bntthue.Click += new System.EventHandler(this.bntthue_Click);
            // 
            // lvChon
            // 
            this.lvChon.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader1});
            this.lvChon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lvChon.FullRowSelect = true;
            this.lvChon.Location = new System.Drawing.Point(6, 19);
            this.lvChon.Name = "lvChon";
            this.lvChon.Size = new System.Drawing.Size(212, 184);
            this.lvChon.TabIndex = 8;
            this.lvChon.UseCompatibleStateImageBehavior = false;
            this.lvChon.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader2
            // 
            this.columnHeader2.DisplayIndex = 1;
            this.columnHeader2.Text = "Tên sách";
            this.columnHeader2.Width = 128;
            // 
            // columnHeader3
            // 
            this.columnHeader3.DisplayIndex = 2;
            this.columnHeader3.Text = "Giá bán";
            this.columnHeader3.Width = 68;
            // 
            // columnHeader1
            // 
            this.columnHeader1.DisplayIndex = 0;
            this.columnHeader1.Text = "Mã sách";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lvChon);
            this.groupBox3.Controls.Add(this.btnHuy);
            this.groupBox3.Controls.Add(this.btnChon);
            this.groupBox3.Location = new System.Drawing.Point(480, 73);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(224, 288);
            this.groupBox3.TabIndex = 8;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Danh sách chọn";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(464, 370);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Tổng tiền mua:";
            // 
            // txtTongTien
            // 
            this.txtTongTien.Location = new System.Drawing.Point(544, 367);
            this.txtTongTien.Name = "txtTongTien";
            this.txtTongTien.ReadOnly = true;
            this.txtTongTien.Size = new System.Drawing.Size(153, 20);
            this.txtTongTien.TabIndex = 11;
            // 
            // txtGiaThue
            // 
            this.txtGiaThue.Location = new System.Drawing.Point(544, 391);
            this.txtGiaThue.Name = "txtGiaThue";
            this.txtGiaThue.ReadOnly = true;
            this.txtGiaThue.Size = new System.Drawing.Size(153, 20);
            this.txtGiaThue.TabIndex = 13;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(464, 394);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 13);
            this.label8.TabIndex = 12;
            this.label8.Text = "Tổng tiền thuê:";
            // 
            // btnNhapTenKhachHang
            // 
            this.btnNhapTenKhachHang.BackColor = System.Drawing.Color.White;
            this.btnNhapTenKhachHang.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNhapTenKhachHang.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(188)))), ((int)(((byte)(156)))));
            this.btnNhapTenKhachHang.FlatAppearance.BorderSize = 3;
            this.btnNhapTenKhachHang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNhapTenKhachHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNhapTenKhachHang.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(188)))), ((int)(((byte)(156)))));
            this.btnNhapTenKhachHang.Location = new System.Drawing.Point(545, 416);
            this.btnNhapTenKhachHang.Name = "btnNhapTenKhachHang";
            this.btnNhapTenKhachHang.Size = new System.Drawing.Size(75, 48);
            this.btnNhapTenKhachHang.TabIndex = 14;
            this.btnNhapTenKhachHang.Text = "Nhập khách mượn";
            this.btnNhapTenKhachHang.UseVisualStyleBackColor = false;
            this.btnNhapTenKhachHang.Click += new System.EventHandler(this.btnNhapTenKhachHang_Click);
            // 
            // FDMT
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(716, 484);
            this.Controls.Add(this.btnNhapTenKhachHang);
            this.Controls.Add(this.txtGiaThue);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtTongTien);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.bntthue);
            this.Controls.Add(this.btnMua);
            this.Controls.Add(this.txtsearch);
            this.Controls.Add(this.btnsearch);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FDMT";
            this.Text = "FDMS";
            this.Load += new System.EventHandler(this.FDMS_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptb)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtnxb;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtgiasach;
        private System.Windows.Forms.TextBox txttensach;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnsearch;
        private DevComponents.DotNetBar.Controls.TextBoxX txtsearch;
        private System.Windows.Forms.ListView lvdms;
        private System.Windows.Forms.Button btnChon;
        private System.Windows.Forms.Button btnHuy;
        private System.Windows.Forms.Button btnMua;
        private System.Windows.Forms.Button bntthue;
        private System.Windows.Forms.PictureBox ptb;
        private System.Windows.Forms.ColumnHeader masach;
        private System.Windows.Forms.ColumnHeader tensach;
        private System.Windows.Forms.ColumnHeader giaban;
        private System.Windows.Forms.ColumnHeader nxb;
        private System.Windows.Forms.ListView lvChon;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtTongTien;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader HinhAnh;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtmasach;
        private System.Windows.Forms.ColumnHeader ID;
        private System.Windows.Forms.TextBox txtGiaThue;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnNhapTenKhachHang;
    }
}