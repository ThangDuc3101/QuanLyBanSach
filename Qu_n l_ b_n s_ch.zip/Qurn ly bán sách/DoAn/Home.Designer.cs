﻿namespace DoAn
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            this.listpanel = new System.Windows.Forms.Panel();
            this.btnthoat = new System.Windows.Forms.Button();
            this.btnbill = new System.Windows.Forms.Button();
            this.btnkhachthue = new System.Windows.Forms.Button();
            this.btnnxb = new System.Windows.Forms.Button();
            this.btnmuathue = new System.Windows.Forms.Button();
            this.btndms = new System.Windows.Forms.Button();
            this.btnkhosach = new System.Windows.Forms.Button();
            this.iconpanel = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.headerpanel = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.mainPanel = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.listpanel.SuspendLayout();
            this.iconpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.headerpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.mainPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // listpanel
            // 
            this.listpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(188)))), ((int)(((byte)(156)))));
            this.listpanel.Controls.Add(this.btnthoat);
            this.listpanel.Controls.Add(this.btnbill);
            this.listpanel.Controls.Add(this.btnkhachthue);
            this.listpanel.Controls.Add(this.btnnxb);
            this.listpanel.Controls.Add(this.btnmuathue);
            this.listpanel.Controls.Add(this.btndms);
            this.listpanel.Controls.Add(this.btnkhosach);
            this.listpanel.Controls.Add(this.iconpanel);
            this.listpanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.listpanel.Location = new System.Drawing.Point(0, 0);
            this.listpanel.Name = "listpanel";
            this.listpanel.Size = new System.Drawing.Size(185, 556);
            this.listpanel.TabIndex = 0;
            // 
            // btnthoat
            // 
            this.btnthoat.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnthoat.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnthoat.FlatAppearance.BorderSize = 0;
            this.btnthoat.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnthoat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnthoat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnthoat.ForeColor = System.Drawing.Color.White;
            this.btnthoat.Location = new System.Drawing.Point(0, 444);
            this.btnthoat.Name = "btnthoat";
            this.btnthoat.Size = new System.Drawing.Size(185, 62);
            this.btnthoat.TabIndex = 7;
            this.btnthoat.Text = "Thoát";
            this.btnthoat.UseVisualStyleBackColor = true;
            this.btnthoat.Click += new System.EventHandler(this.btnthoat_Click);
            // 
            // btnbill
            // 
            this.btnbill.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnbill.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnbill.FlatAppearance.BorderSize = 0;
            this.btnbill.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnbill.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnbill.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbill.ForeColor = System.Drawing.Color.White;
            this.btnbill.Location = new System.Drawing.Point(0, 382);
            this.btnbill.Name = "btnbill";
            this.btnbill.Size = new System.Drawing.Size(185, 62);
            this.btnbill.TabIndex = 6;
            this.btnbill.Text = "Hóa Đơn";
            this.btnbill.UseVisualStyleBackColor = true;
            this.btnbill.Click += new System.EventHandler(this.btnbill_Click);
            // 
            // btnkhachthue
            // 
            this.btnkhachthue.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnkhachthue.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnkhachthue.FlatAppearance.BorderSize = 0;
            this.btnkhachthue.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnkhachthue.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnkhachthue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnkhachthue.ForeColor = System.Drawing.Color.White;
            this.btnkhachthue.Location = new System.Drawing.Point(0, 320);
            this.btnkhachthue.Name = "btnkhachthue";
            this.btnkhachthue.Size = new System.Drawing.Size(185, 62);
            this.btnkhachthue.TabIndex = 4;
            this.btnkhachthue.Text = "Khách Thuê ";
            this.btnkhachthue.UseVisualStyleBackColor = true;
            this.btnkhachthue.Click += new System.EventHandler(this.btnkhachthue_Click);
            // 
            // btnnxb
            // 
            this.btnnxb.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnnxb.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnnxb.FlatAppearance.BorderSize = 0;
            this.btnnxb.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnnxb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnnxb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnxb.ForeColor = System.Drawing.Color.White;
            this.btnnxb.Location = new System.Drawing.Point(0, 258);
            this.btnnxb.Name = "btnnxb";
            this.btnnxb.Size = new System.Drawing.Size(185, 62);
            this.btnnxb.TabIndex = 3;
            this.btnnxb.Text = "Nhà Xuất Bản";
            this.btnnxb.UseVisualStyleBackColor = true;
            this.btnnxb.Click += new System.EventHandler(this.btnnxb_Click);
            // 
            // btnmuathue
            // 
            this.btnmuathue.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnmuathue.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnmuathue.FlatAppearance.BorderSize = 0;
            this.btnmuathue.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnmuathue.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnmuathue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmuathue.ForeColor = System.Drawing.Color.White;
            this.btnmuathue.Location = new System.Drawing.Point(0, 196);
            this.btnmuathue.Name = "btnmuathue";
            this.btnmuathue.Size = new System.Drawing.Size(185, 62);
            this.btnmuathue.TabIndex = 2;
            this.btnmuathue.Text = "Mua, Thuê";
            this.btnmuathue.UseVisualStyleBackColor = true;
            this.btnmuathue.Click += new System.EventHandler(this.btnmuathue_Click);
            // 
            // btndms
            // 
            this.btndms.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btndms.Dock = System.Windows.Forms.DockStyle.Top;
            this.btndms.FlatAppearance.BorderSize = 0;
            this.btndms.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btndms.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btndms.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndms.ForeColor = System.Drawing.Color.White;
            this.btndms.Location = new System.Drawing.Point(0, 134);
            this.btndms.Name = "btndms";
            this.btndms.Size = new System.Drawing.Size(185, 62);
            this.btndms.TabIndex = 2;
            this.btndms.Text = "Danh Mục Sách";
            this.btndms.UseVisualStyleBackColor = true;
            this.btndms.Click += new System.EventHandler(this.btndms_Click_1);
            // 
            // btnkhosach
            // 
            this.btnkhosach.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnkhosach.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnkhosach.FlatAppearance.BorderSize = 0;
            this.btnkhosach.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnkhosach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnkhosach.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnkhosach.ForeColor = System.Drawing.Color.White;
            this.btnkhosach.Location = new System.Drawing.Point(0, 72);
            this.btnkhosach.Name = "btnkhosach";
            this.btnkhosach.Size = new System.Drawing.Size(185, 62);
            this.btnkhosach.TabIndex = 1;
            this.btnkhosach.Text = "Kho Sách";
            this.btnkhosach.UseVisualStyleBackColor = true;
            this.btnkhosach.Click += new System.EventHandler(this.btnkhosach_Click);
            // 
            // iconpanel
            // 
            this.iconpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.iconpanel.Controls.Add(this.pictureBox1);
            this.iconpanel.Controls.Add(this.label1);
            this.iconpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconpanel.Location = new System.Drawing.Point(0, 0);
            this.iconpanel.Name = "iconpanel";
            this.iconpanel.Size = new System.Drawing.Size(185, 72);
            this.iconpanel.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(7, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(63, 61);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(76, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "Book Store";
            // 
            // headerpanel
            // 
            this.headerpanel.BackColor = System.Drawing.Color.White;
            this.headerpanel.Controls.Add(this.pictureBox2);
            this.headerpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.headerpanel.Location = new System.Drawing.Point(185, 0);
            this.headerpanel.Name = "headerpanel";
            this.headerpanel.Size = new System.Drawing.Size(716, 72);
            this.headerpanel.TabIndex = 0;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(716, 72);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // mainPanel
            // 
            this.mainPanel.Controls.Add(this.button3);
            this.mainPanel.Controls.Add(this.button2);
            this.mainPanel.Controls.Add(this.button6);
            this.mainPanel.Controls.Add(this.button5);
            this.mainPanel.Controls.Add(this.button4);
            this.mainPanel.Controls.Add(this.button1);
            this.mainPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainPanel.Location = new System.Drawing.Point(185, 72);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(716, 484);
            this.mainPanel.TabIndex = 1;
            // 
            // button3
            // 
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.Location = new System.Drawing.Point(492, 18);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(160, 160);
            this.button3.TabIndex = 0;
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.Location = new System.Drawing.Point(265, 18);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(160, 160);
            this.button2.TabIndex = 0;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Image = ((System.Drawing.Image)(resources.GetObject("button6.Image")));
            this.button6.Location = new System.Drawing.Point(492, 248);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(160, 160);
            this.button6.TabIndex = 0;
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.Location = new System.Drawing.Point(265, 248);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(160, 160);
            this.button5.TabIndex = 0;
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
            this.button4.Location = new System.Drawing.Point(46, 248);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(160, 160);
            this.button4.TabIndex = 0;
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(46, 18);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(160, 160);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(901, 556);
            this.Controls.Add(this.mainPanel);
            this.Controls.Add(this.headerpanel);
            this.Controls.Add(this.listpanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BookStore";
            this.listpanel.ResumeLayout(false);
            this.iconpanel.ResumeLayout(false);
            this.iconpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.headerpanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.mainPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel listpanel;
        private System.Windows.Forms.Button btnkhachthue;
        private System.Windows.Forms.Button btnnxb;
        private System.Windows.Forms.Button btnmuathue;
        private System.Windows.Forms.Button btnkhosach;
        private System.Windows.Forms.Panel iconpanel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel headerpanel;
        private System.Windows.Forms.Button btnbill;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btnthoat;
        private System.Windows.Forms.Panel mainPanel;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button btndms;
    }
}

